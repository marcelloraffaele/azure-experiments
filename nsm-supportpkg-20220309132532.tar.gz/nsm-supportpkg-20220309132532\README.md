
# Contents of support package

## nginx-mesh/

Directory containing NGINX Service Mesh control plane information.

- nginx-mesh/
	- \<pod-name\>/ - Directory containing Pod-specific information.
		- \<container-name\>-logs.txt: Logs for the container.
		- \<container-name\>-previous-logs.txt: Previous logs for the container (if applicable).
		- desc.txt: Description of the Pod.
		- pod.yaml: Configuration of the Pod.
	- configmaps.yaml: All the ConfigMap configurations in the nginx-mesh namespace.
	- daemonsets.yaml: All the DaemonSet configurations in the nginx-mesh namespace.
	- deployments.yaml: All the Deployment configurations in the nginx-mesh namespace.
	- events.txt: All the Event configurations in the nginx-mesh namespace.
	- metrics.txt: CPU and memory usage of each Pod.
	- pods.txt: Output of "kubectl -n nginx-mesh get pods -o wide".
	- secrets.yaml: All the Secret configurations in the nginx-mesh namespace.
	- serviceaccounts.yaml: All the ServiceAccount configurations in the nginx-mesh namespace.
	- services.yaml: All the Service configurations in the nginx-mesh namespace.
	- statefulsets.yaml: All the StatefulSet configurations in the nginx-mesh namespace.
## \<user-namespace\>/

Directory containing sidecar information.

- \<user-namespace\>/
	- \<pod-name\>/ - Directory containing Pod-specific information.
		- nginx-mesh-init-logs.txt: Logs of the nginx-mesh-init container.
		- nginx-mesh-sidecar-logs.txt: Logs of the nginx-mesh-sidecar container.
		- nginx-mesh-init-previous-logs.txt: Previous logs of the nginx-mesh-init container (if applicable).
		- nginx-mesh-sidecar-previous-logs.txt: Previous logs of the nginx-mesh-sidecar container (if applicable).
		- pod.yaml: Configuration of the Pod.

## Configuration files

- apiservices.yaml: All the NGINX Service Mesh APIService configurations.
- circuitbreakers.yaml: All the CircuitBreaker configurations.
- clusterrolebindings.yaml: All the NGINX Service Mesh ClusterRoleBinding configurations.
- clusterroles.yaml: All the NGINX Service Mesh ClusterRole configurations.
- crds.yaml: All the NGINX Service Mesh Custom Resource Definition (CRD) configurations.
- deploy-config.json: Deploy-time configuration of NGINX Service Mesh.
- httproutegroups.yaml: All the HTTPRouteGroup configurations.
- mesh-config.json: Output of "nginx-meshctl config".
- mutatingwebhookconfigurations.yaml: All the NGINX Service Mesh MutatingWebhookConfiguration configurations.
- ratelimits.yaml: All the RateLimit configurations.
- supportpkg-creation-logs.txt: Logs that occurred while the support package was being created.
- tcproutes.yaml: All the TCPRoute configurations.
- trafficsplits.yaml: All the TrafficSplit configurations.
- traffictargets.yaml: All the TrafficTarget configurations.
- validatingwebhookconfigurations.yaml: All the NGINX Service Mesh ValidatingWebhookConfiguration configurations.
- version.txt: Output of "nginx-meshctl version".
